--
-- PostgreSQL database dump
--

\restrict n7v32v2FY66D2g5ow0K4DuWGpRFyaUlQ8khbWa6wgJhQhgvTIYNwyXWhB2fmBOr

-- Dumped from database version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public."SeasonConfig_temporadaAltaInicio_temporadaAltaFin_key";
DROP INDEX IF EXISTS public."Quote_clientIp_idx";
DROP INDEX IF EXISTS public."DiscountByIP_clientIp_key";
DROP INDEX IF EXISTS public."DiscountByIP_clientIp_idx";
DROP INDEX IF EXISTS public."Contact_timestamp_idx";
ALTER TABLE IF EXISTS ONLY public."SeasonConfig" DROP CONSTRAINT IF EXISTS "SeasonConfig_pkey";
ALTER TABLE IF EXISTS ONLY public."Quote" DROP CONSTRAINT IF EXISTS "Quote_pkey";
ALTER TABLE IF EXISTS ONLY public."DiscountByIP" DROP CONSTRAINT IF EXISTS "DiscountByIP_pkey";
ALTER TABLE IF EXISTS ONLY public."Contact" DROP CONSTRAINT IF EXISTS "Contact_pkey";
DROP TABLE IF EXISTS public."SeasonConfig";
DROP TABLE IF EXISTS public."Quote";
DROP TABLE IF EXISTS public."DiscountByIP";
DROP TABLE IF EXISTS public."Contact";
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Contact; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Contact" (
    id text NOT NULL,
    "tipoServicio" text NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    telefono text NOT NULL,
    descripcion text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    estado text DEFAULT 'nuevo'::text NOT NULL
);


--
-- Name: DiscountByIP; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DiscountByIP" (
    id text NOT NULL,
    "clientIp" text NOT NULL,
    "ultimoDescuentoUsado" timestamp(3) without time zone
);


--
-- Name: Quote; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Quote" (
    id text NOT NULL,
    "clientIp" text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    language text DEFAULT 'es'::text NOT NULL,
    "tipoServicio" text NOT NULL,
    "tipoEquipo" text NOT NULL,
    "metrosCuadrados" integer NOT NULL,
    altura double precision NOT NULL,
    "exposicionSolar" double precision DEFAULT 1.0 NOT NULL,
    "frigoriasCalculadas" integer NOT NULL,
    "modeloSeleccionado" text NOT NULL,
    "marcaSeleccionada" text NOT NULL,
    "precioEquipo" double precision NOT NULL,
    andamio boolean DEFAULT false NOT NULL,
    "andamioPrice" double precision DEFAULT 0 NOT NULL,
    urgencia72h boolean DEFAULT false NOT NULL,
    "urgenciaPrice" double precision DEFAULT 0 NOT NULL,
    "metrosAdicionales" integer DEFAULT 0 NOT NULL,
    "metrosAdicionalesPrice" double precision DEFAULT 0 NOT NULL,
    subtotal double precision NOT NULL,
    iva double precision NOT NULL,
    "descuentoPorcentaje" double precision DEFAULT 0 NOT NULL,
    "descuentoMonto" double precision DEFAULT 0 NOT NULL,
    "totalFinal" double precision NOT NULL,
    "ofertaTemporal" boolean DEFAULT true NOT NULL,
    "nombreCliente" text,
    "emailCliente" text,
    "telefonoCliente" text,
    "direccionCliente" text,
    "codigoPostalCliente" text,
    completado boolean DEFAULT false NOT NULL
);


--
-- Name: SeasonConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SeasonConfig" (
    id text NOT NULL,
    "temporadaAltaInicio" text NOT NULL,
    "temporadaAltaFin" text NOT NULL,
    "precioUrgenciaAlta" double precision NOT NULL,
    "precioUrgenciaBaja" double precision NOT NULL,
    "precioAveriaAlta" double precision NOT NULL,
    "precioAveriaBaja" double precision NOT NULL,
    "precioAndamio" double precision DEFAULT 120 NOT NULL
);


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Contact" (id, "tipoServicio", nombre, email, telefono, descripcion, "timestamp", estado) FROM stdin;
\.


--
-- Data for Name: DiscountByIP; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DiscountByIP" (id, "clientIp", "ultimoDescuentoUsado") FROM stdin;
\.


--
-- Data for Name: Quote; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Quote" (id, "clientIp", "timestamp", language, "tipoServicio", "tipoEquipo", "metrosCuadrados", altura, "exposicionSolar", "frigoriasCalculadas", "modeloSeleccionado", "marcaSeleccionada", "precioEquipo", andamio, "andamioPrice", urgencia72h, "urgenciaPrice", "metrosAdicionales", "metrosAdicionalesPrice", subtotal, iva, "descuentoPorcentaje", "descuentoMonto", "totalFinal", "ofertaTemporal", "nombreCliente", "emailCliente", "telefonoCliente", "direccionCliente", "codigoPostalCliente", completado) FROM stdin;
\.


--
-- Data for Name: SeasonConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SeasonConfig" (id, "temporadaAltaInicio", "temporadaAltaFin", "precioUrgenciaAlta", "precioUrgenciaBaja", "precioAveriaAlta", "precioAveriaBaja", "precioAndamio") FROM stdin;
cmo4h135r0000vh87zw7j5nyg	15/05	15/09	250	150	120	90	120
\.


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: DiscountByIP DiscountByIP_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DiscountByIP"
    ADD CONSTRAINT "DiscountByIP_pkey" PRIMARY KEY (id);


--
-- Name: Quote Quote_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Quote"
    ADD CONSTRAINT "Quote_pkey" PRIMARY KEY (id);


--
-- Name: SeasonConfig SeasonConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeasonConfig"
    ADD CONSTRAINT "SeasonConfig_pkey" PRIMARY KEY (id);


--
-- Name: Contact_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Contact_timestamp_idx" ON public."Contact" USING btree ("timestamp");


--
-- Name: DiscountByIP_clientIp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DiscountByIP_clientIp_idx" ON public."DiscountByIP" USING btree ("clientIp");


--
-- Name: DiscountByIP_clientIp_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DiscountByIP_clientIp_key" ON public."DiscountByIP" USING btree ("clientIp");


--
-- Name: Quote_clientIp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Quote_clientIp_idx" ON public."Quote" USING btree ("clientIp");


--
-- Name: SeasonConfig_temporadaAltaInicio_temporadaAltaFin_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SeasonConfig_temporadaAltaInicio_temporadaAltaFin_key" ON public."SeasonConfig" USING btree ("temporadaAltaInicio", "temporadaAltaFin");


--
-- PostgreSQL database dump complete
--

\unrestrict n7v32v2FY66D2g5ow0K4DuWGpRFyaUlQ8khbWa6wgJhQhgvTIYNwyXWhB2fmBOr

